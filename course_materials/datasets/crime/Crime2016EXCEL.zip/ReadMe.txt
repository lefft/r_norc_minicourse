
**************************************************************************
              ReadMe file for Campus Safety and Security 2016
                                          
              Prepared by IT Innovative Solutions - APR 04, 2017 
**************************************************************************


Crime2016EXCEL.zip contains the following files:

        Noncampusarrest131415.xls           -- noncampus arrest data for year 2013, year 2014 and 2015
        Noncampuscrime131415.xls            -- noncampus criminal offenses data for year 2013, year 2014 and 2015
        Noncampusdiscipline131415.xls       -- noncampus disciplinary actions data for year 2013, year 2014 and 2015
        Noncampushate131415.xlsx            -- noncampus hate crimes data for year 2013, year 2014 and 2015
        Noncampusvawa131415.xls             -- noncampus vawa offenses data for year 2013, year 2014 and 2015
        Oncampusarrest131415.xls            -- on-campus arrest data for year 2013, year 2014 and 2015
        Oncampuscrime131415.xls             -- on-campus criminal offenses data for year 2013, year 2014 and 2015
        Oncampusdiscipline131415.xls        -- on-campus disciplinary actions data for year 2013, year 2014 and 2015
        Oncampushate131415.xlsx             -- on-campus hate crimes data for year 2013, year 2014 and 2015
        Oncampusvawa131415.xls              -- on-campus vawa offenses data for year 2013, year 2014 and 2015
        Publicpropertyarrest131415.xls      -- public property arrest data for year 2013, year 2014 and 2015
        Publicpropertycrime131415.xls       -- public property criminal offenses data for year 2013, year 2014 and 2015
        Publicpropertydiscipline131415.xls  -- public property disciplinary actions data for year 2013, year 2014 and 2015
        Publicpropertyhate131415.xlsx       -- public property hate crimes data for year 2013, year 2014 and 2015
        Publicpropertyvawa131415.xls        -- public property vawa offenses data for year 2013, year 2014 and 2015
        Reportedarrest131415.xls            -- reported by local police arrest data for year 2013, year 2014 and 2015
        Reportedcrime131415.xls             -- reported by local police criminal offenses data for year 2013, year 2014 and 2015
        Reporteddiscipline131415.xls        -- reported by local police disciplinary actions data for year 2013, year 2014 and 2015
        Reportedhate131415.xlsx             -- reported by local police hate crimes data for year 2013, year 2014 and 2015
        Reportedvawa131415.xls              -- reported by local police vawa offenses data for year 2013, year 2014 and 2015
        Residencehallarrest131415.xls       -- residence hall arrest data for year 2013, year 2014 and 2015
        Residencehallcrime131415.xls        -- residence hall criminal offenses data for year 2013, year 2014 and 2015
        Residencehalldiscipline131415.xls   -- residence hall disciplinary actions data for year 2013, year 2014 and 2015
        Residencehallhate131415.xlsx        -- residence hall hate crimes data for year 2013, year 2014 and 2015
        Residencehallvawa131415.xls         -- residence hall vawa offenses data for year 2013, year 2014 and 2015
	Residencehallfire13.xls             -- residence hall fire data for year 2013
        Residencehallfire14.xls             -- residence hall fire data for year 2014
	Residencehallfire15.xls             -- residence hall fire data for year 2015
	Unfounded131415.xls                 -- unfounded crimes data for year 2013, year 2014 and 2015
	
      

Data Dictionaries for Each Excel File
        Noncampusarrest131415_Doc.doc         
        Noncampuscrime131415_Doc.doc                  
        Noncampusdiscipline131415_Doc.doc             
        Noncampushate131415_Doc.doc                   
        Noncampusvawa131415_Doc.doc                   
        Oncampusarrest131415_Doc.doc                  
        Oncampuscrime131415_Doc.doc                   
        Oncampusdiscipline131415_Doc.doc              
        Oncampushate131415_Doc.doc                    
        Oncampusvawa131415_Doc.doc                    
        Publicpropertyarrest131415_Doc.doc            
        Publicpropertycrime131415_Doc.doc             
        Publicpropertydiscipline131415_Doc.doc        
        Publicpropertyhate131415_Doc.doc              
        Publicpropertyvawa131415_Doc.doc              
        Reportedarrest131415_Doc.doc                  
        Reportedcrime131415_Doc.doc                   
        Reporteddiscipline131415_Doc.doc              
        Reportedhate131415_Doc.doc                    
        Reportedvawa131415_Doc.doc                    
        Residencehallarrest131415_Doc.doc             
        Residencehallcrime131415_Doc.doc              
        Residencehalldiscipline131415_Doc.doc         
        Residencehallhate131415_Doc.doc               
        Residencehallvawa131415_Doc.doc               
	Residencehallfire13_Doc.doc                   
        Residencehallfire14_Doc.doc                   
	Residencehallfire15_Doc.doc                   
	Unfounded131415_Doc.doc                       
        
           
   __________________________________________________________________________ 

