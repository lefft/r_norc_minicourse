
**************************************************************************
              ReadMe file for Campus Safety and Security 2016
                                          
              Prepared by IT Innovative Solutions - APR 11, 2017 
**************************************************************************


Crime2016EXCEL.zip contains the following files:

        Noncampusarrest131415.sas7bdat           -- noncampus arrest data for year 2013, year 2014 and 2015
        Noncampuscrime131415.sas7bdat            -- noncampus criminal offenses data for year 2013, year 2014 and 2015
        Noncampusdiscipline131415.sas7bdat       -- noncampus disciplinary actions data for year 2013, year 2014 and 2015
        Noncampushate131415.sas7bdat             -- noncampus hate crimes data for year 2013, year 2014 and 2015
        Noncampusvawa131415.sas7bdat             -- noncampus vawa offenses data for year 2013, year 2014 and 2015
        Oncampusarrest131415.sas7bdat            -- on-campus arrest data for year 2013, year 2014 and 2015
        Oncampuscrime131415.sas7bdat             -- on-campus criminal offenses data for year 2013, year 2014 and 2015
        Oncampusdiscipline131415.sas7bdat        -- on-campus disciplinary actions data for year 2013, year 2014 and 2015
        Oncampushate131415.sas7bdat              -- on-campus hate crimes data for year 2013, year 2014 and 2015
        Oncampusvawa131415.sas7bdat              -- on-campus vawa offenses data for year 2013, year 2014 and 2015
        Publicpropertyarrest131415.sas7bdat      -- public property arrest data for year 2013, year 2014 and 2015
        Publicpropertycrime131415.sas7bdat       -- public property criminal offenses data for year 2013, year 2014 and 2015
        Publicpropertydiscipline131415.sas7bdat  -- public property disciplinary actions data for year 2013, year 2014 and 2015
        Publicpropertyhate131415.sas7bdat        -- public property hate crimes data for year 2013, year 2014 and 2015
        Publicpropertyvawa131415.sas7bdat        -- public property vawa offenses data for year 2013, year 2014 and 2015
        Reportedarrest131415.sas7bdat            -- reported by local police arrest data for year 2013, year 2014 and 2015
        Reportedcrime131415.sas7bdat             -- reported by local police criminal offenses data for year 2013, year 2014 and 2015
        Reporteddiscipline131415.sas7bdat        -- reported by local police disciplinary actions data for year 2013, year 2014 and 2015
        Reportedhate131415.sas7bdat              -- reported by local police hate crimes data for year 2013, year 2014 and 2015
        Reportedvawa131415.sas7bdat              -- reported by local police vawa offenses data for year 2013, year 2014 and 2015
        Residencehallarrest131415.sas7bdat       -- residence hall arrest data for year 2013, year 2014 and 2015
        Residencehallcrime131415.sas7bdat        -- residence hall criminal offenses data for year 2013, year 2014 and 2015
        Residencehalldiscipline131415.sas7bdat   -- residence hall disciplinary actions data for year 2013, year 2014 and 2015
        Residencehallhate131415.sas7bdat         -- residence hall hate crimes data for year 2013, year 2014 and 2015
        Residencehallvawa131415.sas7bdat         -- residence hall vawa offenses data for year 2013, year 2014 and 2015
	Residencehallfire13.sas7bdat             -- residence hall fire data for year 2013
        Residencehallfire14.sas7bdat             -- residence hall fire data for year 2014
	Residencehallfire15.sas7bdat             -- residence hall fire data for year 2015
	Unfounded131415.sas7bdat                 -- unfounded crimes data for year 2013, year 2014 and 2015

           
   __________________________________________________________________________ 

